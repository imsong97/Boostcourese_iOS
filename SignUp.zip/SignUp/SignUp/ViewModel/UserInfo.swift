//
//  UserInfo.swift
//  SignUp
//
//  Created by YunHo on 2021/05/23.
//

import Foundation
import Combine

class UserInfo: ObservableObject {
    
    var id: String = ""
    var password: String = ""
    var checkPassword: String = ""
    var introduce: String = ""
    var phoneNumber: String = ""
    var birth = Date()
    
//    lazy var isMatch: AnyPublisher<Bool, Never> =
//        Publishers.CombineLatest($password, $checkPassword) // Publisher는 $ 표시
//        .map({ (password: String, checkPassword: String) in
//            if password == "" || checkPassword == "" {
//                return false
//            }
//
//            if password == checkPassword {
//                return true
//            }
//            else {
//                return false
//            }
//        })
//        .eraseToAnyPublisher()
}
