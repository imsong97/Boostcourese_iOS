//
//  ContentView.swift
//  SignUp
//
//  Created by YunHo on 2021/05/23.
//

import SwiftUI

struct ContentView: View {
    
    @State var id: String = ""
    @State var password: String = ""
    
    @State var mainView: Bool = false // 메인뷰 변수
    
    var body: some View {
        NavigationView{
            VStack(alignment: .center){
    //            Image("Image")
                
                TextField("ID", text: $id)
                    .textFieldStyle(RoundedBorderTextFieldStyle())
                SecureField("Password", text: $password)
                    .textFieldStyle(RoundedBorderTextFieldStyle())
                
                HStack (alignment: .center, spacing: 100){
                    Button(action: {
                        
                    }, label: {
                        Text("Sign In")
                    })
                    
                    NavigationLink(destination: SignUpView(mainView: $mainView).navigationBarHidden(true),
                                   isActive: $mainView, // 2,3번째 네비게이션 뷰에서 다시 돌아올 때
                        label: {
                            Text("Sign Up")
                                .foregroundColor(.red)
                            }
                    )
//                    Button(action: {
//                        print("action")
//
//                    }, label: {
//                        Text("Sign Up")
//                            .foregroundColor(.red)
//                    })
                }
                .padding(20)
            }
            .padding(70)
            .navigationBarHidden(true)
        }
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
