//
//  ContentView.swift
//  SignUp
//
//  Created by YunHo on 2021/05/23.
//

import SwiftUI

struct ContentView: View {
    
    @State var id: String = ""
    @State var password: String = ""
    
    @State var mainView: Bool = false // 메인뷰 변ㅅ
    
    @State private var showAlert = false
    
    var body: some View {
        NavigationView{
            VStack(alignment: .center){
    //            Image("Image")
                
                TextField("ID", text: $id)
                    .textFieldStyle(RoundedBorderTextFieldStyle())
                SecureField("Password", text: $password)
                    .textFieldStyle(RoundedBorderTextFieldStyle())
                
                HStack (alignment: .center, spacing: 100){
                    Button(action: {
                        isMatchUserInfo() ? self.showAlert = true : print("Login Fail!")
                    }, label: {
                        Text("Sign In")
                    })
                    .alert(isPresented: $showAlert, content: {
                        Alert(title: Text("Login Success!"), message: Text("안녕하세요 \(self.id) 님!"), dismissButton: .default(Text("OK")))
                    })
                    
                    Button(action: {
                        self.mainView = true
                    }, label: {
                        Text("Sign Up")
                            .foregroundColor(.red)
                    })
                    .sheet(isPresented: self.$mainView, content: { // 모달 띄우기
                        SignUpView(mainView: $mainView)
                    })
                }
                .padding(20)
            }
            .padding(70)
            .navigationBarHidden(true)
        }
    }
    
    func isMatchUserInfo() -> Bool {
        if self.id == UserInfo.shared.id && self.password == UserInfo.shared.password {
            return true
        }
        else{
            return false
        }
    }
    
    func loginSuccess() {
        print("Log in!")
        
        let alert = UIAlertController(title: "Login Success!", message: "안녕하세요 \(UserInfo.shared.id) 님!", preferredStyle: UIAlertController.Style.alert)
        let okAction = UIAlertAction(title: "OK", style: .default) { (action) in
                    
                }
        alert.addAction(okAction)
        
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
