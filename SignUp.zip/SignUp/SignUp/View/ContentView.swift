//
//  ContentView.swift
//  SignUp
//
//  Created by YunHo on 2021/05/23.
//

import SwiftUI

struct ContentView: View {
    
    @ObservedObject var userInfo = UserInfo()
    
    @State var id: String = ""
    @State var password: String = ""
    
    @State var mainView: Bool = false // 메인뷰 변ㅅ
    
    var body: some View {
        NavigationView{
            VStack(alignment: .center){
    //            Image("Image")
                
                TextField("ID", text: $id)
                    .textFieldStyle(RoundedBorderTextFieldStyle())
                SecureField("Password", text: $password)
                    .textFieldStyle(RoundedBorderTextFieldStyle())
                
                HStack (alignment: .center, spacing: 100){
                    Button(action: {
                        print("Log in!")
                    }, label: {
                        Text("Sign In")
                    })
                    
                    Button(action: {
                        self.mainView = true
                    }, label: {
                        Text("Sign Up")
                            .foregroundColor(.red)
                    })
                    .sheet(isPresented: self.$mainView, content: { // 모달 띄우기
                        SignUpView(mainView: $mainView)
                    })
                }
                .padding(20)
            }
            .padding(70)
            .navigationBarHidden(true)
        }
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
