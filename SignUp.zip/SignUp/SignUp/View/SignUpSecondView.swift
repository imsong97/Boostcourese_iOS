//
//  UserInfoView.swift
//  SignUp
//
//  Created by YunHo on 2021/05/23.
//

import SwiftUI

struct SignUpSecondView: View {
    
//    @State var phoneNumber: String = ""
//    @State private var date = Date()
    @ObservedObject var userInfo = UserInfo()
    
    @State var birth = Date()
    @State var phoneNumber = ""
    
    @Environment(\.presentationMode) var presentationMode // 이전화면으로 가기위한 변수
    @Binding var mainView: Bool // 메인뷰 바인딩 변수
    
    var body: some View {
        
        VStack(alignment: .center){
            
            VStack(alignment:.leading){
                Text("전화번호")
                    .font(.title2)
                
                TextField("", text: $phoneNumber)
                    .textFieldStyle(RoundedBorderTextFieldStyle())
                    .keyboardType(.numberPad)
                
                HStack(spacing:150){
                    Text("생년월일")
                        .font(.title2)
                    Text("")
                        .font(.title2)
                }
 
                DatePicker("", selection: $userInfo.birth, displayedComponents: .date)
                    .datePickerStyle(GraphicalDatePickerStyle())
            }
            
            HStack(alignment: .center, spacing: 100){
                Button(action: { // 취소 시 데이터 초기화
                    
                    userInfo.id = ""
                    userInfo.password = ""
                    userInfo.phoneNumber = ""
                    
                    mainView = false // 처음화면으로
                }, label: {
                    Text("취소")
                        .foregroundColor(.red)
                })
                
                Button(action: {
                    self.presentationMode.wrappedValue.dismiss() // 이전화면으로
                }, label: {
                    Text("이전")
                })
                
                Button(action: {
                    // 모든 UserInfo 저장
                    userInfo.phoneNumber = phoneNumber
                    mainView = false // 처음화면으로
                    
                }, label: {
                    Text("가입")
                })
//                .disabled(true)
            }
            
            Spacer()
        }
        .padding()
    }
}

//struct UserInfoView_Previews: PreviewProvider {
//    static var previews: some View {
//        SignUpSecondView()
//    }
//}
