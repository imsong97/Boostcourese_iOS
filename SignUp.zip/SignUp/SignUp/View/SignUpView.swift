//
//  SignUpView.swift
//  SignUp
//
//  Created by YunHo on 2021/05/23.
//

import SwiftUI

struct SignUpView: View {

    @State var id: String = ""
    @State var password: String = ""
    @State var checkPassword: String = ""
    @State var intro: String = ""
    
    @Binding var mainView: Bool // 메인뷰 바인딩 변수

    var body: some View {
        NavigationView{
            
            GeometryReader{ geometryReader in
                
                VStack{
                    
                    GeometryReader { g in
                        HStack{
                            Rectangle()
                                .frame(width: g.size.width / 3, height: g.size.width / 3)
                                .foregroundColor(.gray)
                            
                            VStack{
                                TextField("ID", text: $id)
                                    .textFieldStyle(RoundedBorderTextFieldStyle())
                                SecureField("Password", text: $password)
                                    .textFieldStyle(RoundedBorderTextFieldStyle())
                                SecureField("Check Password", text: $checkPassword)
                                    .textFieldStyle(RoundedBorderTextFieldStyle())
                            }
                        }
                        .frame(height: geometryReader.size.height / 5)
                    }
                    .frame(height: geometryReader.size.height / 5)

                    TextField("", text:$intro)
                        .frame(height: 3.5 * geometryReader.size.height / 5)
                        .background(Color.yellow)
                        .aspectRatio(contentMode: .fill)
                    
                    HStack(spacing: 150){
                        Button(action: {
                            mainView = false // 처음화면으로
                        }, label: {
                            Text("취소")
                                .foregroundColor(.red)
                        })
                        
                        NavigationLink(destination:
                                        SignUpSecondView(mainView: $mainView)
                                        .onAppear{
                                            UserInfo.singleton.id = self.id
                                            UserInfo.singleton.password = self.password
                                        }
                                        .navigationBarHidden(true),
                            label: {
                                Text("다음")
                            }
                        )
                        .disabled(!isPasswordMatch())
                        
                    }
                    .frame(height: geometryReader.size.height / 10)
                    
                }
                .padding()
            }
            .navigationBarHidden(true)
        }
    }
    
    func isPasswordMatch() -> Bool{
        // password가 일치하고 id와 intro가 채워질 때 "다음" 버튼 동작
        
        if password == "" || checkPassword == "" {
            return false
        }

        if password == checkPassword && !id.isEmpty {
            return true
        }
        else {
            return false
        }
        
    }
}

//struct SignUpView_Previews: PreviewProvider {
//    static var previews: some View {
//        SignUpView()
//    }
//}
