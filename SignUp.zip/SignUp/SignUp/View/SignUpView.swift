//
//  SignUpView.swift
//  SignUp
//
//  Created by YunHo on 2021/05/23.
//

import SwiftUI

struct SignUpView: View {
    
    @ObservedObject var userInfo = UserInfo()

    @State var checkPassword: String = ""
    
    @Binding var mainView: Bool // 메인뷰 바인딩 변수
    
    var isValid = false
    
    var body: some View {
        NavigationView{
            
            GeometryReader{ geometryReader in
                
                VStack{
                    
                    GeometryReader { g in
                        HStack{
                            Rectangle()
                                .frame(width: g.size.width / 3, height: g.size.width / 3)
                                .foregroundColor(.gray)
                            
                            VStack{
                                TextField("ID", text: $userInfo.id)
                                    .textFieldStyle(RoundedBorderTextFieldStyle())
                                SecureField("Password", text: $userInfo.password)
                                    .textFieldStyle(RoundedBorderTextFieldStyle())
                                SecureField("Check Password", text: $checkPassword)
                                    .textFieldStyle(RoundedBorderTextFieldStyle())
                            }
                        }
                        .frame(height: geometryReader.size.height / 5)
                    }
                    .frame(height: geometryReader.size.height / 5)
                    
                    TextField("", text:$userInfo.introduce)
                        .frame(height: 3.5 * geometryReader.size.height / 5)
                        .background(Color.yellow)
                        .aspectRatio(contentMode: .fill)
                    
                    HStack(spacing: 150){
                        Button(action: {
                            mainView = false // 처음화면으로
                        }, label: {
                            Text("취소")
                                .foregroundColor(.red)
                        })
                        
                        NavigationLink(destination: SignUpSecondView(mainView: $mainView).navigationBarHidden(true),
                            label: {
                                Text("다음")
                            }
                        )
                        .disabled(!isPasswordMatch())
                        
                    }
                    .frame(height: geometryReader.size.height / 10)
                    
                }
                .padding()
            }
            .navigationBarHidden(true)
        }
    }
    
    func isPasswordMatch() -> Bool{
        // password가 일치하고 id와 intro가 채워질 때 "다음" 버튼 동작
        
        if userInfo.password == "" || checkPassword == "" {
            return false
        }

        if userInfo.password == checkPassword && !userInfo.id.isEmpty {
            return true
        }
        else {
            return false
        }
        
    }
}

//struct SignUpView_Previews: PreviewProvider {
//    static var previews: some View {
//        SignUpView()
//    }
//}
