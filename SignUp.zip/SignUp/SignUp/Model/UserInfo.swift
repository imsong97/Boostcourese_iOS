//
//  UserInfo.swift
//  SignUp
//
//  Created by YunHo on 2021/05/23.
//

import Foundation
import Combine

class UserInfo {
    
    static let singleton: UserInfo = UserInfo()
    
    var id: String?
    var password: String?
    var introduce: String?
    var phoneNumber: String?
    var birth = Date()
}
