//
//  SignUpApp.swift
//  SignUp
//
//  Created by YunHo on 2021/05/23.
//

import SwiftUI

@main
struct SignUpApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
